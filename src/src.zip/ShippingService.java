public class ShippingService {
    public static void send(String address) {
        System.out.println("Quantum book store: Sent paper book to " + address);
    }
}
