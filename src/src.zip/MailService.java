public class MailService {
    public static void send(String email) {
        System.out.println("Quantum book store: Sent ebook to " + email);
    }
}
